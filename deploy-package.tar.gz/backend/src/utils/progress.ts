export type TargetType = "AT_LEAST" | "AT_MOST" | "EXACT" | "MAXIMUM" | "MINIMUM";

/**
 * Calculates progress percentage (0 - 100) based on targetType:
 * - AT_LEAST / MINIMUM: higher is better. (current - baseline) / (target - baseline) * 100.
 * - AT_MOST / MAXIMUM: lower is better (max cap). If current <= target -> 100%. If current > target -> penalty.
 * - EXACT: deviation penalty.
 */
export function calculateProgressPercent(
  current: number | null | undefined,
  target: number | null | undefined,
  targetType?: string | null,
  baseline?: number | null
): number {
  if (target === null || target === undefined || isNaN(Number(target))) return 0;
  const curr = Number(current || 0);
  const tgt = Number(target);
  const base = Number(baseline || 0);
  const rawType = (targetType || "AT_LEAST").toUpperCase();
  const type =
    rawType === "MAXIMUM" || rawType === "≤" || rawType === "<="
      ? "AT_MOST"
      : rawType === "MINIMUM" || rawType === "≥" || rawType === ">="
      ? "AT_LEAST"
      : rawType === "="
      ? "EXACT"
      : rawType;

  if (type === "AT_MOST") {
    if (tgt <= 0) {
      return curr <= 0 ? 100 : 0;
    }
    if (curr <= tgt) {
      return 100;
    }
    // Over-target linear penalty
    const over = curr - tgt;
    const progress = Math.max(0, (1 - over / tgt) * 100);
    return Math.round(progress * 10) / 10;
  }

  if (type === "EXACT") {
    if (tgt === 0) {
      return curr === 0 ? 100 : 0;
    }
    const diff = Math.abs(curr - tgt);
    const progress = Math.max(0, (1 - diff / Math.abs(tgt)) * 100);
    return Math.round(progress * 10) / 10;
  }

  // Default: AT_LEAST
  const span = tgt - base;
  if (span <= 0) {
    return curr >= tgt ? 100 : 0;
  }
  const progress = Math.min(100, Math.max(0, ((curr - base) / span) * 100));
  return Math.round(progress * 10) / 10;
}

export function getTargetPrefix(targetType?: string | null): string {
  const rawType = (targetType || "AT_LEAST").toUpperCase();
  const type = rawType === "MAXIMUM" ? "AT_MOST" : rawType === "MINIMUM" ? "AT_LEAST" : rawType;
  if (type === "AT_MOST") return "≤ ";
  if (type === "EXACT") return "= ";
  return "≥ ";
}

export function calculateAutoStatus(
  progressPercent: number
): "ON_TRACK" | "AT_RISK" | "OFF_TRACK" {
  if (progressPercent >= 80) return "ON_TRACK";
  if (progressPercent >= 50) return "AT_RISK";
  return "OFF_TRACK";
}
