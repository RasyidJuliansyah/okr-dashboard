import { Response } from "express";
import { PrismaClient } from "@prisma/client";
import { AuthRequest } from "../middleware/auth.middleware";
import { calculateProgressPercent, calculateAutoStatus } from "../utils/progress";
import { resolveSprint } from "../services/sprint.service";

const prisma = new PrismaClient();

const PERSPECTIVES = [
  "FINANCIAL",
  "CUSTOMER",
  "INTERNAL_PROCESS",
  "LEARNING_GROWTH",
];

export async function getBscOverview(req: AuthRequest, res: Response) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Fetch all annual key results with their parent objectives
    const keyResults = await prisma.annualKeyResult.findMany({
      where: { isActive: true },
      include: {
        objective: {
          select: {
            title: true,
            year: true,
          },
        },
      },
    });

    // Initialize groupings
    const bscData: any = {};
    PERSPECTIVES.forEach((p) => {
      bscData[p] = {
        perspective: p,
        krs: [],
        metrics: {
          totalCount: 0,
          averageProgress: 0,
          onTrackCount: 0,
          atRiskCount: 0,
          offTrackCount: 0,
        },
      };
    });

    // Process and group KRs
    keyResults.forEach((kr) => {
      const p = kr.bscPerspective;
      if (!bscData[p]) return; // Safeguard

      const progress = calculateProgressPercent(
        kr.currentValue,
        kr.targetValue,
        kr.targetType,
      );

      const krWithProgress = {
        ...kr,
        progress,
      };

      bscData[p].krs.push(krWithProgress);
      bscData[p].metrics.totalCount++;

      if (kr.status === "ON_TRACK") bscData[p].metrics.onTrackCount++;
      else if (kr.status === "AT_RISK") bscData[p].metrics.atRiskCount++;
      else if (kr.status === "OFF_TRACK") bscData[p].metrics.offTrackCount++;

      bscData[p].metrics.averageProgress += progress;
    });

    // Finalize averages
    PERSPECTIVES.forEach((p) => {
      const count = bscData[p].metrics.totalCount;
      if (count > 0) {
        bscData[p].metrics.averageProgress =
          Math.round((bscData[p].metrics.averageProgress / count) * 10) / 10;
      }
    });

    return res.status(200).json(bscData);
  } catch (error) {
    console.error("Get BSC overview error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
}

// ─── C-Level Executive BSC Dashboard ──────────────────────────────────────

export async function getCLevelBscDashboard(req: AuthRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });

    const { month, year } = req.query;

    // ponytail: Decouple KRs from sprint cycles. All active KRs remain visible (42 base count),
    // while monthly parameter scopes the linked initiatives.
    let matchedSprintId: string | null = null;
    let resolvedSprintObj: any = null;
    if (month && month !== "ALL") {
      const sp = await resolveSprint({
        sprintId: String(month),
        sprintMonth: String(month),
        fallbackToActive: false,
      });
      matchedSprintId = sp?.id || String(month);
      resolvedSprintObj = sp;
    }

    const where: any = {
      isActive: true,
      objective: {
        isActive: true,
        ...(year ? { year: String(year) } : {}),
      },
    };

    // 1. Fetch all KRs with context
    const keyResults = await prisma.keyResult.findMany({
      where,
      include: {
        objective: { select: { title: true, year: true } },
        assignments: {
          include: {
            user: { select: { id: true, name: true, department: true } },
          },
        },
        departments: { select: { department: true } },
        updates: {
          orderBy: { updatedAt: "asc" },
          select: { newValue: true, updatedAt: true },
        },
        sprintTargets: true,
        initiatives: {
          where: {
            isActive: true,
            ...(matchedSprintId
              ? {
                  OR: [
                    { sprintId: matchedSprintId },
                    { sprintMonth: matchedSprintId },
                    { sprintMonth: String(month) },
                    ...(resolvedSprintObj ? [{ sprintMonth: resolvedSprintObj.name }] : []),
                  ],
                }
              : {}),
          },
          select: {
            id: true,
            title: true,
            description: true,
            currentValue: true,
            targetValue: true,
            targetType: true,
            unit: true,
            status: true,
            kanbanStatus: true,
            team: { select: { id: true, name: true } },
            owner: { select: { id: true, name: true } },
          },
        },
      },
      orderBy: { createdAt: "asc" },
    });

    // 2. Aggregate by BSC perspective
    const perspectiveMap: Record<string, any> = {};
    PERSPECTIVES.forEach((p) => {
      perspectiveMap[p] = {
        perspective: p,
        totalCount: 0,
        onTrackCount: 0,
        atRiskCount: 0,
        offTrackCount: 0,
        totalProgress: 0,
        averageProgress: 0,
        keyResults: [],
      };
    });

    // 3. Department progress aggregation: pre-populate all active departments
    const activeDepartments = await prisma.department.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
    });

    const deptMap: Record<
      string,
      {
        code: string;
        name: string;
        totalProgress: number;
        count: number;
        keyResults: any[];
      }
    > = {};

    activeDepartments.forEach((d) => {
      deptMap[d.value] = {
        code: d.value,
        name: d.name,
        totalProgress: 0,
        count: 0,
        keyResults: [],
      };
    });

    // 4. Critical KRs
    const criticalKrs: any[] = [];

    // 5. Trend: bucket KrUpdates by ISO-week (last 8 weeks)
    const now = new Date();
    const trendWeeks: { label: string; weekStart: Date }[] = [];
    for (let i = 7; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i * 7);
      d.setHours(0, 0, 0, 0);
      // Set to Monday of that week
      const day = d.getDay();
      d.setDate(d.getDate() - (day === 0 ? 6 : day - 1));
      const label = `${d.toLocaleString("default", { month: "short" })} W${Math.ceil(d.getDate() / 7)}`;
      trendWeeks.push({ label, weekStart: new Date(d) });
    }

    // trendAccum[perspective][weekIndex] = { sum, count }
    const trendAccum: Record<string, { sum: number; count: number }[]> = {};
    PERSPECTIVES.forEach((p) => {
      trendAccum[p] = Array.from({ length: 8 }, () => ({ sum: 0, count: 0 }));
    });

    keyResults.forEach((kr) => {
      const p = kr.bscPerspective;
      if (!perspectiveMap[p]) return;

      const mappedInitiatives = (kr.initiatives || []).map((init: any) => {
        let initProg = calculateProgressPercent(
          init.currentValue,
          init.targetValue,
          init.targetType,
        );
        if (init.kanbanStatus === "DONE" && initProg < 100) {
          initProg = 100;
        }
        return {
          id: init.id,
          title: init.title,
          description: init.description,
          currentValue: init.currentValue,
          targetValue: init.targetValue,
          targetType: init.targetType,
          unit: init.unit,
          status: init.status,
          kanbanStatus: init.kanbanStatus,
          progress: Math.round(initProg * 10) / 10,
          team: init.team,
          owner: init.owner,
        };
      });

      const st = matchedSprintId
        ? kr.sprintTargets?.find((t: any) => t.sprintId === matchedSprintId)
        : null;

      const isSprintActive =
        !matchedSprintId ||
        (resolvedSprintObj
          ? resolvedSprintObj.status === "ACTIVE"
          : true);

      let progressRounded = 0;
      let krStatus = kr.status;
      let displayCurrentValue = kr.currentValue;
      let displayTargetValue = kr.targetValue;

      if (matchedSprintId) {
        if (st && st.targetValue > 0) {
          progressRounded = calculateProgressPercent(
            st.currentValue,
            st.targetValue,
            kr.targetType,
            st.baselineValue || 0,
          );
          krStatus = kr.isManualOverride
            ? kr.status
            : (st.currentValue === (st.baselineValue || 0) && progressRounded === 0)
            ? "NOT_STARTED"
            : calculateAutoStatus(progressRounded);
          displayCurrentValue = st.currentValue;
          displayTargetValue = st.targetValue;
        } else if (mappedInitiatives.length > 0) {
          const sumProg = mappedInitiatives.reduce(
            (s: number, ini: any) => s + ini.progress,
            0,
          );
          progressRounded =
            Math.round((sumProg / mappedInitiatives.length) * 10) / 10;
          krStatus = kr.isManualOverride
            ? kr.status
            : progressRounded === 0
            ? "NOT_STARTED"
            : calculateAutoStatus(progressRounded);
        } else if (isSprintActive) {
          progressRounded = calculateProgressPercent(
            kr.currentValue,
            kr.targetValue,
            kr.targetType,
          );
          krStatus = kr.status;
        } else {
          // Sprint UPCOMING or CLOSED without targets/initiatives for this KR
          progressRounded = 0;
          krStatus = "NOT_STARTED";
          displayCurrentValue = 0;
        }
      } else {
        progressRounded = calculateProgressPercent(
          kr.currentValue,
          kr.targetValue,
          kr.targetType,
        );
        krStatus = kr.status;
      }

      perspectiveMap[p].totalCount++;
      perspectiveMap[p].totalProgress += progressRounded;

      if (krStatus === "ON_TRACK") perspectiveMap[p].onTrackCount++;
      else if (krStatus === "AT_RISK") perspectiveMap[p].atRiskCount++;
      else if (krStatus === "OFF_TRACK") perspectiveMap[p].offTrackCount++;

      const responsibleAssignment = kr.assignments.find((a: any) => a.raciRole === "RESPONSIBLE");
      const responsible = responsibleAssignment?.user ?? kr.assignments[0]?.user ?? null;
      const accountables = kr.assignments
        .filter((a: any) => a.raciRole === "ACCOUNTABLE")
        .map((a: any) => a.user)
        .filter(Boolean);
      const assignments = kr.assignments.map((a: any) => ({
        raciRole: a.raciRole,
        user: a.user,
      }));
      const krDepts = kr.departments.map((d: any) => d.department);

      perspectiveMap[p].keyResults.push({
        id: kr.id,
        title: kr.title,
        bscPerspective: kr.bscPerspective,
        status: krStatus,
        progress: progressRounded,
        currentValue: displayCurrentValue,
        targetValue: displayTargetValue,
        targetType: kr.targetType,
        unit: kr.unit,
        objectiveTitle: kr.objective.title,
        year: kr.objective.year,
        month: kr.month,
        isActive: kr.isActive ? 1 : 0,
        responsible,
        accountables,
        assignments,
        departments: krDepts,
        initiatives: mappedInitiatives,
      });

      // Department aggregation - associate KR with all its departments (KrDepartment + assigned users)
      const krDeptCodes = new Set<string>();
      kr.departments.forEach((d) => krDeptCodes.add(d.department));
      kr.assignments.forEach((a) => {
        if (a.user?.department) krDeptCodes.add(a.user.department);
      });

      if (krDeptCodes.size === 0) {
        if (kr.objective.title.includes("B2B")) krDeptCodes.add("B2B_CORPORATE");
        else if (kr.objective.title.includes("B2C")) krDeptCodes.add("B2C");
        else if (kr.objective.title.includes("B2S")) krDeptCodes.add("B2S");
      }

      krDeptCodes.forEach((deptCode) => {
        if (!deptMap[deptCode]) {
          deptMap[deptCode] = {
            code: deptCode,
            name: deptCode,
            totalProgress: 0,
            count: 0,
            keyResults: [],
          };
        }
        deptMap[deptCode].totalProgress += progressRounded;
        deptMap[deptCode].count++;
        deptMap[deptCode].keyResults.push({
          id: kr.id,
          title: kr.title,
          progress: progressRounded,
          status: krStatus,
          currentValue: displayCurrentValue,
          targetValue: displayTargetValue,
          targetType: kr.targetType,
          unit: kr.unit,
          bscPerspective: kr.bscPerspective,
          objectiveTitle: kr.objective.title,
          responsible,
          accountables,
          assignments,
        });
      });

      // Critical KRs (AT_RISK or OFF_TRACK)
      if (krStatus === "AT_RISK" || krStatus === "OFF_TRACK") {
        criticalKrs.push({
          id: kr.id,
          title: kr.title,
          bscPerspective: kr.bscPerspective,
          status: krStatus,
          progress: progressRounded,
          currentValue: displayCurrentValue,
          targetValue: displayTargetValue,
          unit: kr.unit,
          objectiveTitle: kr.objective.title,
          year: kr.objective.year,
          responsible,
          accountables,
          assignments,
          departments: kr.departments.map((d) => d.department),
        });
      }

      // Trend mapping: each KrUpdate to the appropriate week bucket
      if (kr.updates.length > 0) {
        kr.updates.forEach((upd) => {
          const updDate = new Date(upd.updatedAt);
          for (let wi = trendWeeks.length - 1; wi >= 0; wi--) {
            if (updDate >= trendWeeks[wi].weekStart) {
              const pct = calculateProgressPercent(
                upd.newValue,
                kr.targetValue,
                kr.targetType,
              );
              trendAccum[p][wi].sum += pct;
              trendAccum[p][wi].count++;
              break;
            }
          }
        });
      }
    });

    // Finalize perspective averages
    PERSPECTIVES.forEach((p) => {
      const count = perspectiveMap[p].totalCount;
      perspectiveMap[p].averageProgress =
        count > 0
          ? Math.round((perspectiveMap[p].totalProgress / count) * 10) / 10
          : 0;
      delete perspectiveMap[p].totalProgress;
    });

    // Finalize trend data
    const trendData: Record<string, (number | null)[]> = {};
    PERSPECTIVES.forEach((p) => {
      trendData[p] = trendAccum[p].map((b) =>
        b.count > 0 ? Math.round((b.sum / b.count) * 10) / 10 : null,
      );
    });

    // Department averages, sorted by progress desc (departments with KRs first, then 0 KR)
    const byDepartment = Object.values(deptMap)
      .map((d) => ({
        department: d.name,
        departmentCode: d.code,
        departmentName: d.name,
        averageProgress:
          d.count > 0 ? Math.round((d.totalProgress / d.count) * 10) / 10 : 0,
        krCount: d.count,
        keyResults: d.keyResults.sort((a, b) => b.progress - a.progress),
      }))
      .sort((a, b) => {
        if (b.krCount === 0 && a.krCount > 0) return -1;
        if (a.krCount === 0 && b.krCount > 0) return 1;
        return b.averageProgress - a.averageProgress;
      });

    // Overall health score = mean of non-empty perspectives
    const nonEmpty = PERSPECTIVES.filter(
      (p) => perspectiveMap[p].totalCount > 0,
    );
    const overallHealthScore =
      nonEmpty.length > 0
        ? Math.round(
            (nonEmpty.reduce(
              (s, p) => s + perspectiveMap[p].averageProgress,
              0,
            ) /
              nonEmpty.length) *
              10,
          ) / 10
        : 0;

    const totalKRs = keyResults.length;
    let totalOnTrack = 0;
    let totalAtRisk = 0;
    let totalOffTrack = 0;
    PERSPECTIVES.forEach((p) => {
      totalOnTrack += perspectiveMap[p].onTrackCount;
      totalAtRisk += perspectiveMap[p].atRiskCount;
      totalOffTrack += perspectiveMap[p].offTrackCount;
    });

    // Calculate monthly health scores across all 12 sprint months for the year
    const targetYear = req.query.year
      ? parseInt(String(req.query.year))
      : month && month !== "ALL" && /^\d{4}/.test(String(month))
      ? parseInt(String(month).split("-")[0])
      : 2026;

    const allSprints = await prisma.sprint.findMany({
      where: {
        OR: [
          { year: String(targetYear) },
          { name: { contains: String(targetYear) } },
        ],
      },
      orderBy: { startDate: "asc" },
    });

    const MONTH_NAMES_ID = [
      "Januari", "Februari", "Maret", "April", "Mei", "Juni",
      "Juli", "Agustus", "September", "Oktober", "November", "Desember",
    ];

    const monthlyHealthScores: Record<string, number | null> = {};
    for (let m = 1; m <= 12; m++) {
      const mStr = `${targetYear}-${String(m).padStart(2, "0")}`;
      const mName = MONTH_NAMES_ID[m - 1];
      const sp = allSprints.find(
        (s) => s.name.includes(mName) && s.name.includes(String(targetYear)),
      );

      const monthKrs = keyResults.filter(
        (k) => k.month === mStr || (sp && k.month === sp.id),
      );
      const spInis = sp
        ? await prisma.initiative.findMany({
            where: {
              isActive: true,
              OR: [{ sprintId: sp.id }, { sprintMonth: sp.name }],
            },
            select: {
              id: true,
              keyResultId: true,
              currentValue: true,
              targetValue: true,
              targetType: true,
              kanbanStatus: true,
            },
          })
        : [];
      const spTargets = sp
        ? await prisma.krSprintTarget.findMany({
            where: { sprintId: sp.id },
          })
        : [];
      const hasAchievements =
        monthKrs.length > 0 ||
        spInis.length > 0 ||
        spTargets.length > 0 ||
        (sp && sp.status === "ACTIVE");

      if (!hasAchievements) {
        monthlyHealthScores[mStr] = null;
        continue;
      }

      const pSums: Record<string, { sum: number; count: number }> = {};
      PERSPECTIVES.forEach((p) => {
        pSums[p] = { sum: 0, count: 0 };
      });

      keyResults.forEach((kr) => {
        const p = kr.bscPerspective;
        if (!pSums[p]) return;
        const st = sp
          ? spTargets.find((t: any) => t.keyResultId === kr.id)
          : null;
        const krInis = sp
          ? spInis.filter((i: any) => i.keyResultId === kr.id)
          : [];

        let prog = 0;
        if (st && st.targetValue > 0) {
          prog = calculateProgressPercent(
            st.currentValue,
            st.targetValue,
            kr.targetType,
            st.baselineValue || 0,
          );
        } else if (krInis.length > 0) {
          const sumIni = krInis.reduce((acc: number, ini: any) => {
            let ip = calculateProgressPercent(
              ini.currentValue,
              ini.targetValue,
              ini.targetType,
            );
            if (ini.kanbanStatus === "DONE" && ip < 100) ip = 100;
            return acc + ip;
          }, 0);
          prog = Math.round((sumIni / krInis.length) * 10) / 10;
        } else if (sp && (kr.month === sp.id || kr.month === mStr)) {
          prog = calculateProgressPercent(
            kr.currentValue,
            kr.targetValue,
            kr.targetType,
          );
        } else if (sp && sp.status === "ACTIVE") {
          prog = calculateProgressPercent(
            kr.currentValue,
            kr.targetValue,
            kr.targetType,
          );
        }

        pSums[p].sum += prog;
        pSums[p].count++;
      });

      const validPs = PERSPECTIVES.filter((p) => pSums[p].count > 0);
      if (validPs.length === 0) {
        monthlyHealthScores[mStr] = null;
      } else {
        const avgP =
          validPs.reduce((acc, p) => acc + pSums[p].sum / pSums[p].count, 0) /
          validPs.length;
        monthlyHealthScores[mStr] = Math.round(avgP * 10) / 10;
      }
    }

    // YTD Health Score: aggregate of all months that have monthly achievements
    const validScores = Object.values(monthlyHealthScores).filter(
      (s): s is number => s !== null && s !== undefined,
    );
    const ytdHealthScore =
      validScores.length > 0
        ? Math.round(
            (validScores.reduce((sum, s) => sum + s, 0) / validScores.length) *
              10,
          ) / 10
        : overallHealthScore;

    const isSprintActive =
      !matchedSprintId ||
      (resolvedSprintObj
        ? resolvedSprintObj.status === "ACTIVE"
        : true);

    const sprintHasAchievements =
      isSprintActive ||
      keyResults.some((kr: any) => {
        const st = matchedSprintId
          ? kr.sprintTargets?.find((t: any) => t.sprintId === matchedSprintId)
          : null;
        if (st && st.currentValue > 0) return true;
        const inis = kr.initiatives || [];
        return inis.some(
          (i: any) => (i.currentValue || 0) > 0 || i.kanbanStatus === "DONE",
        );
      });

    const finalOverallHealthScore =
      !month || month === "ALL"
        ? ytdHealthScore
        : sprintHasAchievements
        ? overallHealthScore
        : null;

    return res.status(200).json({
      overallHealthScore: finalOverallHealthScore,
      ytdHealthScore,
      monthlyHealthScores,
      totalKRs,
      totalOnTrack,
      totalAtRisk,
      totalOffTrack,
      bscByPerspective: perspectiveMap,
      criticalKrs: criticalKrs.sort((a, b) => a.progress - b.progress),
      byDepartment,
      trendData,
      trendLabels: trendWeeks.map((w) => w.label),
    });
  } catch (error) {
    console.error("Get C-Level BSC dashboard error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
}

// ─── OKR Cascading Tree & Matrix Data ──────────────────────────────────────

export async function getCascadingTree(req: AuthRequest, res: Response) {
  try {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });

    const {
      quarter,
      sprintId,
      teamId,
      employeeId,
      perspective,
      year,
      status,
      search,
    } = req.query as Record<string, string | undefined>;

    // 1. Fetch reference lists for filters
    const [allSprints, allTeams, allUsers] = await Promise.all([
      prisma.sprint.findMany({
        where: { isActive: true },
        orderBy: { orderIndex: "asc" },
        select: { id: true, name: true, status: true, year: true, startDate: true, endDate: true },
      }),
      prisma.team.findMany({
        where: { isActive: true },
        orderBy: { name: "asc" },
        select: { id: true, name: true, department: true },
      }),
      prisma.user.findMany({
        where: { isActive: true },
        orderBy: { name: "asc" },
        select: { id: true, name: true, role: true, department: true, position: true, teamId: true },
      }),
    ]);

    // 2. Fetch full hierarchy of Objectives -> KeyResults -> Initiatives -> Tasks
    const objectives = await prisma.objective.findMany({
      where: {
        isActive: true,
        ...(year && year !== "ALL" ? { year: { contains: year.replace("FY ", "") } } : {}),
        ...(quarter && quarter !== "ALL"
          ? {
              OR: [
                { quarter: { equals: quarter } },
                { year: { contains: quarter } },
              ],
            }
          : {}),
      },
      include: {
        keyResults: {
          where: {
            isActive: true,
            ...(perspective && perspective !== "ALL" ? { bscPerspective: perspective } : {}),
            ...(status && status !== "ALL" ? { status } : {}),
          },
          include: {
            departments: true,
            sourceLinksA: {
              where: { isActive: true },
              include: {
                targetKr: {
                  select: {
                    id: true,
                    title: true,
                    status: true,
                    bscPerspective: true,
                    departments: true,
                    initiatives: {
                      select: {
                        team: { select: { id: true, name: true } },
                      },
                    },
                  },
                },
              },
            },
            sourceLinksB: {
              where: { isActive: true },
              include: {
                sourceKr: {
                  select: {
                    id: true,
                    title: true,
                    status: true,
                    bscPerspective: true,
                    departments: true,
                    initiatives: {
                      select: {
                        team: { select: { id: true, name: true } },
                      },
                    },
                  },
                },
              },
            },
            assignments: {
              include: {
                user: {
                  select: { id: true, name: true, email: true, department: true, position: true, role: true },
                },
              },
            },
            initiatives: {
              where: {
                isActive: true,
                ...(sprintId && sprintId !== "ALL" ? { sprintId } : {}),
                ...(teamId && teamId !== "ALL" ? { teamId } : {}),
              },
              include: {
                team: { select: { id: true, name: true } },
                owner: { select: { id: true, name: true, email: true, position: true } },
                assignedLeader: { select: { id: true, name: true, email: true } },
                sprint: { select: { id: true, name: true } },
                tasks: {
                  where: {
                    isActive: true,
                    ...(sprintId && sprintId !== "ALL" ? { sprintId } : {}),
                    ...(employeeId && employeeId !== "ALL" ? { assignedTeamMemberId: employeeId } : {}),
                  },
                  include: {
                    assignedTeamMember: {
                      select: { id: true, name: true, email: true, position: true },
                    },
                    sprint: { select: { id: true, name: true } },
                  },
                },
              },
            },
          },
        },
      },
      orderBy: { createdAt: "asc" },
    });


    // 3. Perspectives metadata and filtering
    const perspectiveMeta: Record<string, { label: string; code: string; color: string }> = {
      FINANCIAL: { label: "Finance", code: "FIN", color: "#10b981" },
      CUSTOMER: { label: "Customer", code: "CUS", color: "#3b82f6" },
      INTERNAL_PROCESS: { label: "Internal Process", code: "PRC", color: "#8b5cf6" },
      LEARNING_GROWTH: { label: "Learning & Growth", code: "LRN", color: "#f59e0b" },
    };

    const treePerspectives: any[] = [];
    const teamCounts: Record<string, { name: string; count: number }> = {};
    allTeams.forEach((t) => {
      teamCounts[t.id] = { name: t.name, count: 0 };
    });

    const searchLower = (search || "").toLowerCase().trim();

    PERSPECTIVES.forEach((pKey) => {
      if (perspective && perspective !== "ALL" && perspective !== pKey) {
        return;
      }

      const pMeta = perspectiveMeta[pKey] || { label: pKey, code: pKey.slice(0, 3), color: "#38bdf8" };
      const pObjectives: any[] = [];
      let pTotalKrs = 0;
      let pOnTrack = 0;
      let pAtRisk = 0;
      let pOffTrack = 0;
      let pProgressSum = 0;

      objectives.forEach((obj) => {
        const krsForP = obj.keyResults.filter((kr) => kr.bscPerspective === pKey);
        if (krsForP.length === 0) return;

        const processedKrs: any[] = [];

        krsForP.forEach((kr) => {
          if (employeeId && employeeId !== "ALL") {
            const isAssignedKr = kr.assignments.some((a) => a.userId === employeeId);
            const isInitiativeOwner = kr.initiatives.some((i) => i.ownerId === employeeId);
            const isTaskAssignee = kr.initiatives.some((i) =>
              i.tasks.some((t) => t.assignedTeamMemberId === employeeId),
            );
            if (!isAssignedKr && !isInitiativeOwner && !isTaskAssignee) return;
          }

          if (teamId && teamId !== "ALL") {
            const hasTeamInit = kr.initiatives.some((i) => i.teamId === teamId);
            const hasTeamDept = kr.departments.some((d) => {
              const matchedTeam = allTeams.find((t) => t.department === d.department);
              return matchedTeam?.id === teamId;
            });
            if (!hasTeamInit && !hasTeamDept) return;
          }

          if (searchLower) {
            const matchesObj = obj.title.toLowerCase().includes(searchLower);
            const matchesKr = kr.title.toLowerCase().includes(searchLower);
            const matchesInit = kr.initiatives.some((i) => i.title.toLowerCase().includes(searchLower));
            const matchesTask = kr.initiatives.some((i) =>
              i.tasks.some((t) => t.title.toLowerCase().includes(searchLower)),
            );
            const matchesTeam = kr.initiatives.some((i) => i.team?.name?.toLowerCase().includes(searchLower));
            if (!matchesObj && !matchesKr && !matchesInit && !matchesTask && !matchesTeam) return;
          }

          const roundedProgress = calculateProgressPercent(
            kr.currentValue,
            kr.targetValue,
            kr.targetType,
          );

          kr.initiatives.forEach((i) => {
            if (teamCounts[i.teamId]) teamCounts[i.teamId].count++;
          });

          const primaryAssignment = kr.assignments.find((a) => a.raciRole === "RESPONSIBLE") || kr.assignments[0];
          const primaryOwner = primaryAssignment?.user || null;

          let depts = kr.departments.map((d) => d.department);
          if (depts.length === 0) {
            const titleMatch = kr.title.match(/^\[([^\]]+)\]/);
            if (titleMatch) {
              depts = [titleMatch[1]];
            } else if (kr.initiatives.length > 0 && kr.initiatives[0].team?.name) {
              depts = [kr.initiatives[0].team.name];
            }
          }

          processedKrs.push({
            id: kr.id,
            title: kr.title,
            targetValue: kr.targetValue,
            currentValue: kr.currentValue,
            unit: kr.unit,
            status: kr.status,
            progress: roundedProgress,
            targetType: kr.targetType,
            bscPerspective: kr.bscPerspective,
            month: kr.month,
            departments: depts,
            owner: primaryOwner,
            assignments: kr.assignments,
            causalLinks: {
              outbound: (kr.sourceLinksA || []).map((l: any) => ({
                id: l.id,
                relationship: l.relationship,
                targetKrId: l.targetKr?.id,
                targetKrTitle: l.targetKr?.title,
                targetPerspective: l.targetKr?.bscPerspective,
                targetTeams: (l.targetKr?.departments || []).map((d: any) => d.department).length
                  ? l.targetKr.departments.map((d: any) => d.department)
                  : (l.targetKr?.initiatives || []).map((i: any) => i.team?.name).filter(Boolean),
              })),
              inbound: (kr.sourceLinksB || []).map((l: any) => ({
                id: l.id,
                relationship: l.relationship,
                sourceKrId: l.sourceKr?.id,
                sourceKrTitle: l.sourceKr?.title,
                sourcePerspective: l.sourceKr?.bscPerspective,
                sourceTeams: (l.sourceKr?.departments || []).map((d: any) => d.department).length
                  ? l.sourceKr.departments.map((d: any) => d.department)
                  : (l.sourceKr?.initiatives || []).map((i: any) => i.team?.name).filter(Boolean),
              })),
            },
            initiatives: kr.initiatives.map((init) => {
              let initProg = calculateProgressPercent(
                init.currentValue,
                init.targetValue,
                init.targetType,
              );
              if (
                (init.kanbanStatus === "DONE" || init.status === "DONE") &&
                initProg < 100
              ) {
                initProg = 100;
              }

              const mappedTasks = init.tasks.map((task) => {
                let taskProg = calculateProgressPercent(
                  task.currentValue,
                  task.targetValue,
                  task.targetType,
                  task.baselineValue,
                );
                if (
                  (task.kanbanStatus === "DONE" || task.status === "DONE") &&
                  taskProg < 100
                ) {
                  taskProg = 100;
                }
                return {
                  id: task.id,
                  title: task.title,
                  description: task.description,
                  targetValue: task.targetValue,
                  currentValue: task.currentValue,
                  targetType: task.targetType,
                  baselineValue: task.baselineValue,
                  unit: task.unit,
                  status: task.status,
                  kanbanStatus: task.kanbanStatus,
                  progress: taskProg,
                  assignedTeamMember: task.assignedTeamMember,
                  assignedUser: task.assignedTeamMember,
                  sprint: task.sprint,
                };
              });

              return {
                id: init.id,
                title: init.title,
                description: init.description,
                targetValue: init.targetValue,
                currentValue: init.currentValue,
                targetType: init.targetType,
                unit: init.unit,
                status: init.status,
                kanbanStatus: init.kanbanStatus,
                progress: initProg,
                sprintMonth: init.sprintMonth,
                sprint: init.sprint,
                team: init.team,
                owner: init.owner,
                tasks: mappedTasks,
                kpis: mappedTasks,
              };
            }),
          });

          pTotalKrs++;
          pProgressSum += roundedProgress;
          if (kr.status === "ON_TRACK") pOnTrack++;
          else if (kr.status === "AT_RISK") pAtRisk++;
          else if (kr.status === "OFF_TRACK") pOffTrack++;
        });

        if (processedKrs.length > 0) {
          const objProgress =
            Math.round(
              (processedKrs.reduce((sum, k) => sum + k.progress, 0) / processedKrs.length) * 10,
            ) / 10;

          pObjectives.push({
            id: obj.id,
            title: obj.title,
            description: obj.description,
            quarter: obj.quarter,
            year: obj.year,
            progress: objProgress,
            status: objProgress >= 70 ? "ON_TRACK" : objProgress >= 40 ? "AT_RISK" : "OFF_TRACK",
            keyResults: processedKrs,
          });
        }
      });

      if (pObjectives.length > 0 || !perspective || perspective === "ALL") {
        treePerspectives.push({
          id: pKey,
          key: pKey,
          name: pMeta.label,
          code: pMeta.code,
          color: pMeta.color,
          totalKrs: pTotalKrs,
          totalObjectives: pObjectives.length,
          averageProgress: pTotalKrs > 0 ? Math.round((pProgressSum / pTotalKrs) * 10) / 10 : 0,
          onTrackCount: pOnTrack,
          atRiskCount: pAtRisk,
          offTrackCount: pOffTrack,
          objectives: pObjectives,
        });
      }
    });

    const totalActiveKrs = treePerspectives.reduce((sum, p) => sum + p.totalKrs, 0);
    const totalTeamHits = Object.values(teamCounts).reduce((s, t) => s + t.count, 0) || 1;
    const teamDistribution = Object.values(teamCounts)
      .filter((t) => t.count > 0)
      .map((t) => ({
        name: t.name,
        krCount: t.count,
        percentage: Math.round((t.count / totalTeamHits) * 100),
      }))
      .sort((a, b) => b.krCount - a.krCount);

    return res.status(200).json({
      root: {
        title: "BSC-OKR Suite",
        subtitle: "SKOLLA STRATEGY 2026",
        year: year || "FY 2026",
      },
      perspectives: treePerspectives,
      totalActiveKrs,
      teamDistribution,
      filterOptions: {
        perspectives: PERSPECTIVES.map((p) => ({
          value: p,
          label: perspectiveMeta[p]?.label || p,
        })),
        sprints: allSprints,
        teams: allTeams,
        employees: allUsers,
        quarters: ["ALL", "Q1", "Q2", "Q3", "Q4", "Annual"],
        years: ["FY 2026", "2026", "Q3-2026"],
        statuses: [
          { value: "ALL", label: "Semua Status" },
          { value: "ON_TRACK", label: "On Track (>70%)" },
          { value: "AT_RISK", label: "At Risk (40% - 70%)" },
          { value: "OFF_TRACK", label: "Off Track (<40%)" },
        ],
      },
    });
  } catch (error) {
    console.error("Get cascading tree error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
}


