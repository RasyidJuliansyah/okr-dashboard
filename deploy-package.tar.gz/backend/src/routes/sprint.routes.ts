import { Router } from "express";
import { authMiddleware, roleGuard } from "../middleware/auth.middleware";
import {
  getSprints,
  getActiveSprint,
  generateYearly,
  updateSprint,
  toggleLock,
  closeSprint,
  getSprintMemberScores,
  getSprintReport,
  upsertKrSprintTarget,
  backfillSprints,
} from "../controllers/sprint.controller";

const router = Router();

// Public / Authenticated read routes
router.get("/", authMiddleware, getSprints);
router.get("/active", authMiddleware, getActiveSprint);
router.get("/:id/member-scores", authMiddleware, getSprintMemberScores);
router.get("/:id/report", authMiddleware, getSprintReport);

// Admin-only management routes
router.post("/generate-yearly", authMiddleware, roleGuard(["ADMIN"]), generateYearly);
router.put("/:id", authMiddleware, roleGuard(["ADMIN"]), updateSprint);
router.post("/:id/toggle-lock", authMiddleware, roleGuard(["ADMIN"]), toggleLock);
router.post("/:id/close", authMiddleware, roleGuard(["ADMIN"]), closeSprint);
router.post("/kr-target", authMiddleware, roleGuard(["ADMIN", "MANAGER"]), upsertKrSprintTarget);
router.post("/backfill", authMiddleware, roleGuard(["ADMIN"]), backfillSprints);


export default router;
